# Lists
Some Lists of useful stuff I find overtime

Not under any licenses but please don't try to sell a shitty list of things

Made by:
Alessandro Mauri
